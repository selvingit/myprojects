#!/usr/bin/env perl
##################################################################
#  FILENAME		:	migration.pl
#  DESC	   		:	script for SVN migration
#  Author  		:	Pavan Kumar A & Thulasi T
#  Date	   		:	25-09-2012
#  Usage		:	perl migration.pl
#  Version		:	V1.0 
#  Explanation	:	
##################################################################

####### Getting system date and time ################
my $time1 = localtime; 

my $currdate = `date +"%d%m%Y_%H%M%S"`;
my $crdate = "$currdate";
chomp($crdate);

my $curdate = `date +"%d%m%Y"`;
my $cdate = "$curdate";
chomp($cdate);

############## Getting User Home Path  ################

my $u_home = `echo \$HOME`;
my $usr_home = "$u_home";
chomp($usr_home);

############## Getting Paths ##############
my $currDir = "$usr_home/scripts/migration";
my $srcDir = "$usr_home/project_folder_copy";
my $wcDir = "$usr_home/working_copy";
my $expDir = "$usr_home/subversion_export_copy";
my $logDir = "$usr_home/logs/migration";

my $inputArray;
my $TrunkName;
my $TrunkLable;
my $BranchName;
my $BranchLable;
my $repo_path;
my $brnch_path;
my $tag_path;
$TrunkFlag = 0;
$BranchFlag = 0;
my $PreTrunkLable;
my $PreBranchName;
my $PreBranchLable;
my $logrepo;

my $propFile = "$currDir"."/"."migration.properties";
#print "Properties File : $propFile \n";
open(PROPERTY,"$propFile");
seek(PROPERTY,0,0);
@propArray=<PROPERTY>;
for my $repo (@propArray)
{
$repo =~ m/^(.+);(.+);(.+);(.+);(.+)$/;
	$projName = $1;
	$repo_path= $2;
	$usr = $3;
	$pswd = $4;
	$logrepo = $5;
	chomp($logrepo);
}
$brnch_path = $repo_path;
$brnch_path =~ s{(trunk).*}{branches}gi;
$tag_path = $repo_path;
$tag_path =~ s{(trunk).*}{tags}gi;
$tag_path =~ s{(branches).*}{tags}gi;


###Log verification should be created here ..........
if ( ! -e "$logDir/$projName")
{
`mkdir "$logDir/$projName"`;
}
my $Log = "$logDir/$projName/$projName".".log";

if (-e $Log)
{
`mv $Log "$Log\_$crdate"`; 
}

open(STDOUT, ">$Log");
open(STDERR, ">&STDOUT");

print "\nSTARTED READING THE FLAT FILE $time1\n";

my $inputFile = "$currDir"."/"."migration.input";
#print "Input File : $inputFile\n";
open(INPUT,"$inputFile");
seek(INPUT,0,0);
@inputArray=<INPUT>;
for my $line (@inputArray)
	{
	my $TrunkName = ' ';
	my $TrunkLable  = ' ';
	my $BranchName = ' ';
	my $BranchLable = ' ';
	$line =~ m/^(.+):(.+):(.+):(.+)$/;
	$TrunkName = $1;
	$TrunkLable = $2;
	$BranchName = $3;
	$BranchLable = $4;
	
	print "Input line is $line\n";
	print "trunk name is $TrunkName\n";
	print "trunk label name is $TrunkLable\n";
	print "Branch name is $BranchName\n";
	print "Branch label is $BranchLable\n\n";
	print "TrunkFlag is $TrunkFlag\n";
	print "BranchFlag is $BranchFlag\n";
	
	my $baseDir = "$srcDir/$TrunkName"; 
	my $chkout_path ="$wcDir/$TrunkName";
	if ( ! -e "$chkout_path")
	{
		`mkdir "$wcDir/$TrunkName"`;
		$chkout_path = "$wcDir/$TrunkName";
	}
		
	my $export_path = "$expDir/$TrunkName";
	if ( ! -e "$export_path")
	{
		`mkdir "$expDir/$TrunkName"`;
		$export_path = "$expDir/$TrunkName";
	}
	
#	START : Verify the directory availability with the same name as that of lable
	for my $line (@inputArray)
        	{
        	my $TrunkDir = "$baseDir"."/"."$TrunkLable";
        	my $BranchDir = "$baseDir"."/"."$BranchLable";
        	if ($TrunkLable ne "X")
                {
                unless ( -d $TrunkDir )
                        {
                        die(" Trunk folder : Folder with the name $TrunkLable doesnt exist\n");
                        }

                }
        	if ($BranchLable ne "X")
                {
                unless ( -d $BranchDir )
                        {
                        die("Branch Folder :Folder with the name $BranchLable doesnt exist\n");
                        }
                }

        	}

#END : Verify the directory availability with the same name as that of lable

	if ( $TrunkFlag == 0 )
		{
		my $time2 = localtime;
		
		print "TRUNK: Create Trunk $TrunkName & Add Source Base & Create Tag for the lable: $TrunkLable\n\n";	
		
		print "********** $TrunkLable initial Importing to $repo_path/$TrunkName - $time2 ***********\n";
		
		my $import = `svn import --force --username $usr --password $pswd --non-interactive "$baseDir/$TrunkLable" "$repo_path/$TrunkName" -m "Initial importing $TrunkLable"`;

		die "$! $TrunkLable importing not successfull \n" if $?;
		
		my $folder1="$baseDir/$TrunkLable";
		
		print "\n Importing files list :\n$import";
		
		my $time3 = localtime;
		
		print "\n **********Importing Succesffuly executed - $time3 ********** \n\n";
		
		`svn mkdir --username $usr --password $pswd --non-interactive "$tag_path/$TrunkName" -m "adding a $TrunkName in tags"`;
		
		die "$! creation of $tag_path/$TrunkName directory not successfull \n" if $?;
		
		
		`svn cp --username $usr --password $pswd --non-interactive "$repo_path/$TrunkName" "$tag_path/$TrunkName/$TrunkName\_$cdate\_$TrunkLable" -m "creation of $TrunkLable tag"`;

		die "$! creation of $TrunkLable tag not successfull \n" if $?;
				
		print "\n ********** $TrunkName\_$cdate\_$TrunkLable Tag Creation completed ********** \n\n";

		`svn export --username $usr --password $pswd --non-interactive "$tag_path/$TrunkName/$TrunkName\_$cdate\_$TrunkLable" "$export_path/$TrunkName\_$cdate\_$TrunkLable"`;
		
		die "$! Exporting of $TrunkLable not successfull \n" if $?;

		print "\n ********** $TrunkName\_$cdate\_$TrunkLable exporting completed to $export_path ********** \n\n";
		
		my $folder2="$export_path/$TrunkName\_$cdate\_$TrunkLable";
		
		`sh $usr_home/scripts/folder_diff/cmp.sh $folder1 $folder2 $TrunkName`;
		
		`svn checkout --force --username $usr --password $pswd --non-interactive "$repo_path/$TrunkName" "$chkout_path/$TrunkName\_WC"`;
		
		die "$! creation of working copy $chkout_path/$TrunkName not successfull \n" if $?;
		
		print "********** working copy created successfully in $chkout_path/$TrunkName\_WC **********\n\n";
		
		$TrunkFlag = 1;
		}
	elsif ( $TrunkFlag != 0 && $PreTrunkLable ne $TrunkLable )
		{
		
		print "TRUNK: Delete the existing code on Trunk $TrunkName & add the new source & create a tag for lable : $TrunkLable \n";
				
		`svn delete --username $usr --password $pswd --non-interactive $chkout_path/$TrunkName\_WC/*`;
		
		die "$! Deletion of working copy $chkout_path/$TrunkName\_WC sources not successfull \n" if $?;
		
		my $com = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$TrunkName\_WC -m "added $TrunkLable data are committed"`;
		die "$! committing working copy $chkout_path/$TrunkName sources not successfull \n" if $?;
		print "********** Deletion of working copy sources completed $chkout_path/$TrunkName\_WC ********** \n";

		`cp -r $baseDir/$TrunkLable/* $chkout_path/$TrunkName\_WC`;
		
		my $folder1 = "$baseDir/$TrunkLable";
		
		die "$! copying of $TrunkLable to working copy $chkout_path/$TrunkName\_WC not successfull \n" if $?;
		
		print "********** copying of $TrunkLable to working copy $chkout_path/$TrunkName\_WC completed ********** \n";

		`svn add --force --username $usr --password $pswd --non-interactive -q $chkout_path/$TrunkName\_WC/*`;
		
		die "$! adding working copy $chkout_path/$TrunkName\_WC sources not successfull \n" if $?;
		
		my $time4 = localtime;
		
		my $com = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$TrunkName\_WC -m "added $TrunkLable data are committed"`;
		
		die "$! committing working copy $chkout_path/$TrunkName sources not successfull \n" if $?;
		
		print "\n **********Working copy sources are going to commit - $time4 ********** \n";
		
		print "$TrunkName Working copy ($TrunkLable) sources list: \n$com";
		
		my $time5 = localtime;
		
		print "\n **********commit sources successfully - $time5 ********** \n\n";
		
		`svn cp --username $usr --password $pswd --non-interactive $repo_path/$TrunkName $tag_path/$TrunkName/$TrunkName\_$cdate\_$TrunkLable -m "creation of $TrunkLable tag"`;
		
		die "$! creation of $TrunkLable tag not successfull \n" if $?;
		
		`svn export --username $usr --password $pswd --non-interactive $tag_path/$TrunkName/$TrunkName\_$cdate\_$TrunkLable $export_path/$TrunkName\_$cdate\_$TrunkLable`;
		
		my $folder2 = "$export_path/$TrunkName\_$cdate\_$TrunkLable";
		
		`sh $usr_home/scripts/folder_diff/cmp.sh $folder1 $folder2 $TrunkName`;
				
		$PreTrunkLable = $TrunkLable;
		
		}
	if ($BranchFlag == 0 && $BranchName ne "X" && $BranchLable ne "X")
		{
		print "BRANCH: Create a branch $BranchName & Add sources & Create a tag for lable : $BranchLable\n";
	
		`svn mkdir --username $usr --password $pswd --non-interactive "$brnch_path/$TrunkName" -m "adding a $TrunkName in branches"`;
		
		die "$! creation of $brnch_path/$TrunkName directory not successfull \n" if $?;
	
	
		`svn cp --username $usr --password $pswd --non-interactive $repo_path/$TrunkName $brnch_path/$TrunkName/$BranchName -m "creation of $TrunkLable branch"`;
		
		die "$! creation of $BranchName branch not successfull \n" if $?;
		
		`svn checkout --force --username $usr --password $pswd --non-interactive "$brnch_path/$TrunkName/$BranchName" "$chkout_path/$BranchName\_WC"`;
		
		die "$! creation of working copy $chkout_path/$BranchName not successfull \n" if $?;
		
		`svn delete --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC/* `;
		
		die "$! Deletion of working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
		
		my $com1 = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC -m "added $BranchLable data are committed"`;
		die "$! committing working copy $chkout_path/$BranchName sources not successfull \n" if $?;
		`cp -r $baseDir/$BranchLable/* $chkout_path/$BranchName\_WC`;
		
		die "$! copying of $BranchLable to working copy $chkout_path/$BranchName\_WC not successfull \n" if $?;
		
		my $folder1 = "$baseDir/$BranchLable";
		
		`svn add --force --username $usr --password $pswd --non-interactive -q $chkout_path/$BranchName\_WC/*`;
		
		die "$! adding working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
		
		my $time6 = localtime;
		
		my $com1 = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC -m "added $BranchLable data are committed"`;
		
		die "$! committing working copy $chkout_path/$BranchName sources not successfull \n" if $?;
		
		print "\n **********Working copy sources are going to commit - $time6 ********** \n";
		
		print "$BranchName working copy sources ($BranchLable) sources list:\n$com1";
		
		my $time7 = localtime;
		
		print "\n ********** commit sources successfully - $time7 ********** \n\n";
		
		`svn cp --username $usr --password $pswd --non-interactive $brnch_path/$TrunkName/$BranchName $tag_path/$TrunkName/$BranchName\_$cdate\_$BranchLable -m "creation of $BranchLable tag"`;
		
		die "$! creation of $BranchName\_$cdate\_$BranchLable tag not successfull \n" if $?;
		
		`svn export --username $usr --password $pswd --non-interactive $tag_path/$TrunkName/$BranchName\_$cdate\_$BranchLable $export_path/$BranchName\_$cdate\_$BranchLable`;
		
		my $folder2 = "$export_path/$BranchName\_$cdate\_$BranchLable";
		
		`sh $usr_home/scripts/folder_diff/cmp.sh $folder1 $folder2 $TrunkName`;
		
		$BranchFlag = 1;
		$PreBranchName = $BranchName;
		}
	 elsif($BranchFlag != 0 )
		{
			if ($BranchName eq $PreBranchName)
				{
				print "BRANCH: Delete the existing code on branch $BranchName & add the new source & create a tag for lable : $BranchLable \n";
			
				`svn del --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC/* `;
		
				die "$! Deletion of working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
			     my $com2 = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC -m "added $BranchLable data are committed"`;
				 die "$! committing working copy $chkout_path/$BranchName sources not successfull \n" if $?;
				`cp -r $baseDir/$BranchLable/* $chkout_path/$BranchName\_WC`;	
		
				die "$! copying of $BranchLable to working copy $chkout_path/$BranchName not successfull \n" if $?;
			
				my $folder1 = "$baseDir/$BranchLable";
			
				`svn add --force --username $usr --password $pswd --non-interactive -q $chkout_path/$BranchName\_WC/*`;
	
				die "$! adding working copy $chkout_path/$BranchName sources not successfull \n" if $?;
			
				my $time8 = localtime;
		
				my $com2 = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC -m "added $BranchLable data are committed"`;

				die "$! committing working copy $chkout_path/$BranchName sources not successfull \n" if $?;
			
				print "\n ********** Working Copy Sources are going to commit - $time8 ********** \n";		

				print "$BranchName working copy sources ($BranchLable) sources list:\n$com2";
			
				my $time9 = localtime;
		
				print "\n ********** commit sources successfully - $time9 ********** \n\n";
						
				`svn cp --username $usr --password $pswd --non-interactive $brnch_path/$TrunkName/$BranchName $tag_path/$TrunkName/$BranchName\_$cdate\_$BranchLable -m "creation of $BranchLable tag"`;
			
				die "$! creation of $BranchName\_$cdate\_$BranchLable tag not successfull \n" if $?;
			
				`svn export --username $usr --password $pswd --non-interactive $tag_path/$TrunkName/$BranchName\_$cdate\_$BranchLable $export_path/$BranchName\_$cdate\_$BranchLable`;
		
				my $folder2 = "$export_path/$BranchName\_$cdate\_$BranchLable";
		
				`sh $usr_home/scripts/folder_diff/cmp.sh $folder1 $folder2 $TrunkName`;
			
				}
			elsif ($BranchName ne $PreBranchName && $BranchName ne "X" && $BranchLable ne "X")
				{
				print "BRANCH: Create a branch $BranchName & Add sources & Create a tag for lable : $BranchLable\n";
			
				`svn cp --username $usr --password $pswd --non-interactive $repo_path/$TrunkName $brnch_path/$TrunkName/$BranchName -m "creation of $TrunkLable branch"`;
		
				die "$! creation of $BranchName branch not successfull \n" if $?;
			
				`svn checkout --force --username $usr --password $pswd --non-interactive $brnch_path/$TrunkName/$BranchName $chkout_path/$BranchName\_WC`;
		
				die "$! creation of working copy $chkout_path/$BranchName\_WC not successfull \n" if $?;
			
				`svn del --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC/* `;
		
				die "$! Deletion of working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
			     my $com3 = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC -m "added $BranchLable data are committed"`;
				 die "$! committing working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
				`cp -r $baseDir/$BranchLable/* $chkout_path/$BranchName\_WC`;
		
				die "$! copying of $BranchLable to working copy $chkout_path/$BranchName\_WC not successfull \n" if $?;
			
				my $folder1 = "$baseDir/$BranchLable";
			
				`svn add --force --username $usr --password $pswd --non-interactive -q $chkout_path/$BranchName\_WC/*`;
		
				die "$! adding working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
			
				my $time10 = localtime;
			
				my $com3 = `svn commit --username $usr --password $pswd --non-interactive $chkout_path/$BranchName\_WC -m "added $BranchLable data are committed"`;
		
				die "$! committing working copy $chkout_path/$BranchName\_WC sources not successfull \n" if $?;
			
				print "\n ********** Working Copy Sources are going to commit - $time10 ********** \n";
			
				print "$BranchName\_WC working copy sources ($BranchLable) sources list:\n$com3";
			
				my $time11 = localtime;
			
				print "\n ********** committing Sources successfully - $time11 ********** \n\n";
			
				`svn cp --username $usr --password $pswd --non-interactive $brnch_path/$TrunkName/$BranchName $tag_path/$TrunkName/$BranchName\_$cdate\_$BranchLable -m "creation of $BranchLable tag"`;

				die "$! creation of $BranchName\_$cdate\_$BranchLable tag not successfull \n" if $?;
			
				`svn export --username $usr --password $pswd --non-interactive $tag_path/$TrunkName/$BranchName\_$cdate\_$BranchLable $export_path/$BranchName\_$cdate\_$BranchLable`;
		
				my $folder2 = "$export_path/$BranchName\_$cdate\_$BranchLable";
		
				`sh $usr_home/scripts/folder_diff/cmp.sh $folder1 $folder2 $TrunkName`;
			
				$PreBranchName = $BranchName;
				}
		}
			print " ************************End of cycle************************** \n\n";
	}
	
# START: Importing of Log files into CM_repository

my $timestamp = localtime;

print "***** Importing the $TrunkName logfiles into $logrepo - $timestamp *****\n";

`svn import --username $usr --password $pswd --non-interactive "$logDir/$projName" "$logrepo/$projName" -m "adding $TrunkName.log file in $TrunkName under $logrepo"`;

die "$! Importing of $projName.log file into $logrepo not successfull \n" if $?;

`svn import --username $usr --password $pswd --non-interactive "$usr_home/logs/folder_diff/$projName" "$logrepo/$projName/folder_diff" -m "adding log files of diff_report under $logrepo"`;

die "$! Importing of $projName diff_repot log files into $logrepo not successfull \n" if $?;

print "**** Importing of $TrunkName logfiles into $logrepo completed *****\n";

# End: Importing of the Log files Completed


### End of the Script #####