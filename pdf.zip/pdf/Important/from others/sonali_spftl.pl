$trunk="http://cms01.spftl.com:8000/svn/ORTB/trunk/SPFTL_CBS/CBS_10.0";
$branch ="http://cms01.spftl.com:8000/svn/ORTB/branches/BANGLADESH/BANGLADESH_R1.0";
$workspace ="/cms-usr/cms/jenkins/jobs/BANGLADESH_R1.0/workspace";
$bsource ="/cms-usr/cms/jenkins/jobs/BANGLADESH_R1.0";
$bdest ="/cms-usr/cms/jenkins/jobs/BANGLADESH_R1.0/workspace/Source";
$file ="envsetup.sh";

#print $trunk;
#print $branch;
#print $workspace;
$usr = "svnadmin";
$password = "NewSvnAdmin";


`rm -rf $workspace`;

`mkdir $workspace`;


`svn export --force --username $usr --password $password $trunk $workspace` or die("\n $! Export not successful!! Execute some SVN command and do build again............., Error");

`svn export --force --username $usr --password $password $branch $workspace` or die("\n $! Export not successful!! Execute some SVN command and do build again............., Error");

`copy $bsource$file $bdest`;