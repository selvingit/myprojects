#!/usr/bin/env perl

#use File::Copy;
#use Getopt::Long;
use File::Basename;


`svn update .`;


$source="https://svnsource/CMS/branches/HSBC_R2.0/Reports/jasper";

print "\nEnter the Starting date(yyyy-mm-dd):";
chomp (my $sdate=<STDIN>);

print "\nEnter the ending date(yyyy-mm-dd):";
chomp (my $edate=<STDIN>);

$jasper_src="C:\\Documents and Settings\\svn\\Desktop\\HSBC_REPORTTEMP@\@dont delete\\Backoffice  REPORTTEMP\\REPORTTEMP";
$jasper_dst="C:\\Documents and Settings\\svn\\Desktop\\Reporttemp_$sdate";

`mkdir "C:\\Documents and Settings\\svn\\Desktop\\Reporttemp_$sdate"`;
`mkdir "C:\\Documents and Settings\\svn\\Desktop\\Reporttemp_$sdate\\sub reports"`;

`svn diff -r {$edate}:{$sdate} --summarize $source > ..\\..\\difflist.txt`;

open (out, ">..\\..\\output.txt");
open (list, "C:\\Documents and Settings\\svn\\Desktop\\HSBC_REPORTTEMP@\@dont delete\\difflist.txt");


while ($line=<list>)
	{
            chomp($line);
		@arr=split /\/jasper\//, $line;
 		
		$filename=$arr[-1];
	
		$filename =~ s/^\///;
		$filename =~ s/\//\\/;
            		
            print out "$filename  \n";		
            	
		`copy "$jasper_src\\$filename" "$jasper_dst\\$filename"`;
	}
close list;
close out;





