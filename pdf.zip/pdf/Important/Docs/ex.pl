#!/usr/bin/env perl
#if (`more +2 taglist.log`)
#{print "if loop working \n";}
#else
#{print "if loop not working \n";}
print "\n 1.Offshore SIT \n 2.Regression \n 3.Offshore UAT \n 4.Onsite UAT \n Enter the Environment: \n";
chomp (my $m=<STDIN>);
if ($m eq int($m) && $m > 0 && $m < 5 )
{
	
	if ($m eq 1)
	{
	print "\n 1.Back office \n 2.Front office \n 3.Online co-ordiantor \n 4.Offline co-ordiantor \n 5.Report Schedular \n Enter the Application: \n";
	chomp (my $n=<STDIN>);
	
		if ($n eq int($n) && $n > 0 && $n < 5 )
		{
		#Offshore SIT and 5 applications

			if ($n eq 1)
			{
				print "\n 1.Offshore sit and backoffice \n";
				$offSIT_bo = "https://svnsource/CMS/tags/HSBC_R2.0/Backoffice/OffshoreSIT";
			}
			elsif ($n eq 2)
			{
				print "\n 1.Offshore sit and frontoffice \n";
				$offSIT_fo = "https://svnsource/CMS/tags/HSBC_R2.0/Frontoffice/OffshoreSIT";
			}
			elsif ($n eq 3)
			{
				print "\n 1.Offshore sit and online cordinator \n";
				$offSIT_onco_ord = "https://svnsource/CMS/tags/HSBC_R2.0/Onlinecoordinator/OffshoreSIT";
			}
			elsif ($n eq 4)
			{
				print "\n 1.Offshore sit and offline cordinator \n";
				$offSIT_offco_ord = "https://svnsource/CMS/tags/HSBC_R2.0/Offlinecoordinator/OffshoreSIT";
			}
			elsif ($n eq 5)
			{
				print "\n 1.Offshore sit and Report Schedular \n";
				$offSIT_RS = "https://svnsource/CMS/tags/HSBC_R2.0/Reportscheduler/OffshoreSIT";
			}		
		}
		else
		{
		print "\n invalid input \n";
		}		
	}
	elsif ($m eq 2)
	{
	print "\n 1.Back office \n 2.Online co-ordiantor \n 3.Report Schedular \n Enter the Application: \n";
	chomp (my $n=<STDIN>);
	
		if ($n eq int($n) && $n > 0 && $n < 3 )
		{
		
		#Regression and 3 applications
		
			if ($n eq 1)
			{
				print "\n Regression and backoffice \n";
				$rg_bo = "https://svnsource/CMS/tags/HSBC_R2.0/Backoffice/Regression";
			}
			#elsif ($n eq 2)
			#{
			#	print "\n Regression and online coordinator \n";
			#	$rg_onco_ord = "https://svnsource/CMS/tags/HSBC_R2.0/Onlinecoordinator/Regression";
				print "\n not in use \n";			
			#}
			elsif ($n eq 3)
			{
				print "\n Regression sit and report schedular \n";
				$rg_RS = "https://svnsource/CMS/tags/HSBC_R2.0/Reportscheduler/Regression";
			}
		}
		else
		{
		print "\n invalid input \n";
		}
	}	
	elsif ($m eq 3)
	{
		print "\n 1.Back office \n Enter the Application: \n";
		chomp (my $n=<STDIN>);
	
		if ($n eq int($n) && $n > 0 && $n < 2 )
		{
		
		#Offshore UAT and 1 applications

			if ($n eq 1)
			{
				print "\n Offshore UAT and backoffice \n";
				$offUAT_bo = "https://svnsource/CMS/tags/HSBC_R2.0/Backoffice/offshoreUAT";
				`svn ls -v $offUAT_bo | sort \\r | head -3 > taglist.txt`;
				open()
				open()
				
				`svn ls -v $tag_path/$tag1 | sort \\r > tag1list.txt`;
		
				if (`more +2 tag1list.txt`)
				{
					`svn diff --summarize $tag_path/$tag1 $tag_path/$tag2 > difflist.txt`;
				}
				else
				{
					print "$tag_path1 Tag empty,  \n";
				}
			}
		}
		else
		{
		print "\n invalid input \n";
		}
	}
	else
	{
	print "\n 1.Back office \n 2.Front office \n 3.Online co-ordiantor \n 4.Offline co-ordiantor \n 5.Report Schedular \n Enter the Application: \n";
	chomp (my $n=<STDIN>);
	
		if ($n eq int($n) && $n > 0 && $n < 5 )
		{
		#Onsite UAT and 5 applications

			if ($n eq 1)
			{
				print "\n Onsite UAT and backoffice \n";
				$onUAT_bo = "https://svnsource/CMS/tags/HSBC_R2.0/Backoffice/OnsiteUAT";
			}
			elsif ($n eq 2)
			{
				print "\n Onsite UAT and frontoffice \n";
				$onUAT_fo = "https://svnsource/CMS/tags/HSBC_R2.0/Frontoffice/OnsiteUAT";
			}
			elsif ($n eq 3)
			{
				print "\n Onsite UAT and online cordinator \n";
				$onUAT_onco_ord = "https://svnsource/CMS/tags/HSBC_R2.0/Onlinecoordinator/OnsiteUAT";
			}
			elsif ($n eq 4)
			{
				print "\n Onsite UAT and offline cordinator \n";
				$onUAT_offco_ord = "https://svnsource/CMS/tags/HSBC_R2.0/Offlinecoordinator/OnsiteUAT";
			}
			elsif ($n eq 5)
			{
				print "\n Onsite UAT and Report Schedular \n";
				$onUAT_RS = "https://svnsource/CMS/tags/HSBC_R2.0/Reportscheduler/OnsiteUAT";
			}		
		}
		else
		{
		print "\n invalid input \n";
		}		
	}	
}	
else 
{
	print "Invalid Input\n";
}

open (out, ">..\\..\\output.txt");
open (file, "taglist.log");
while(<file>)
#{
print "$_ \n";
@arr = split " ",$_;
#print "$arr[-1] \n";
$regex = $arr[1] =~ m/(\w+)/g;
print $1;
#print "\n\n";
#}