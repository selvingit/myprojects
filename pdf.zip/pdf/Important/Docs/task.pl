#!/usr/bin/env perl

use File::Copy;
use Getopt::Long;
use File::Basename;

print "\nEnter the working copy path:";
chomp (my $mash=<STDIN>);

#print "\nEnter the Source Path:";
#chomp (my $sou=<STDIN>);

#print "\nEnter last build revision no.:";
#chomp (my $old=<STDIN>);

#print "\nEnter latest build revision no.:";
#chomp (my $new=<STDIN>);

#print "\nEnter the tag path:";
#chomp(my $dest=<STDIN>);

#`svn diff --summarize -r $old:$new $sou > difflist.txt`;

#open (out, ">output.txt");
#open (list, "difflist.txt");
#while ($line=<list>)
#	{
#		@arr=split /\s+/, $line;
#		print out "$arr[1]  \n";		
#	}
#close list;
#close out;
$abc=`mkdir "diff_Dir"`;
chomp ($ban="$mash/diff_Dir");
chdir $ban;
open (hello, "$mash/output.txt");
foreach(<hello>)
	{
		$str=$_;
		chomp($str);
		@ar=split /:/, $str;
		$folder=dirname($ar[2]);
		$folder=~s/\/Repo\/trunk//g;
		$folder=~s/\//\\/g;
		$folder=~s/^\\//g;
		print "$folder\n";
		`mkdir "$folder"`;
		`svn add $ban`;
	}