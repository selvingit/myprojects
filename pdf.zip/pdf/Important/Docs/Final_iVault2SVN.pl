#!/usr/bin/env perl

print "\nEnter the Number of Baselined sources you plan to migrate:";
chomp (my $n=<STDIN>);

print "\nEnter the repository path to import data[Trunk / Branch]:";
chomp (my $repo_path=<STDIN>);

print "\nEnter the required working path:";
chomp (my $wc_path=<STDIN>);

print "\nEnter the Baseline path to import:";
chomp (my $Baseline_1=<STDIN>);

############### Initialisation ##############################

$tag_path = $repo_path;
$tag_path =~ s{(trunk).*}{tags}gi;
$tag_path =~ s{(branches).*}{tags}gi;

$usr = "thulasi.t";
$pswd = "thulasi.t";

@project1 = split "/+",$Baseline_1;
$proj_name1 = "$project1[-1]";

@wc = split "/+",$wc_path;
$wc_name = "$wc[-1]";

############# Importing Baseline_1 initially into repository ############

`svn import --force --username $usr --password $pswd $Baseline_1 $repo_path -m "Initial importing" > "$proj_name1.txt"`;

die "$! $proj_name1 import not successful " if $?;

print "\n Successfully imported Baseline_1 data into $repo_path \n";

#################### creating baseline_1 tag ############################

`svn cp --username $usr --password $pswd $repo_path "$tag_path/$proj_name1" -m "creation of baseline_1 tag"`;

die "$! creation of $proj_name1 tag not successful " if $?;

print "\n successfully created baseline_1 tag \n";

####################### checkouting working copy ########################

`svn checkout --force --username $usr --password $pswd $repo_path $wc_path > wc_log.txt`;

die "$! $wc_path workingcopy creation not successful " if $?;

print "\n $wc_path checkout completed \n";

################## deleting working copy data ###########################

if ($n gt 1) {

for ($count = 2; $count <= $n; $count++){

my $confirm="";
my $confirm1="";


print "\n You are deleting $proj_name1 sources from $wc_path, please confirm[Yes/No]? \n";
chomp ($confirm=<STDIN>);

if (lc($confirm) eq "yes"){

`svn del --force --username $usr --password $pswd -q $wc_path/* `;

die "$! deletion of working copy sources not successful " if $?;

print "\n successfully deleted working copy sources\n";
}else {
print "\n do you want to delete working copy sources and continue, please confirm [Yes/No]? \n";
chomp ($confirm1=<STDIN>);
if (lc($confirm1) eq "yes"){

`svn del --force --username $usr --password $pswd -q $wc_path/* `;

die "$! deletion of working copy sources not successful " if $?;

print "\n successfully deleted working copy sources\n";

}else {
print "\n working copy sources not deleted and going to exit \n";
exit;
}
}
#########################################################################

print "\nEnter the $count Baseline path :";
chomp (my $Baseline_2=<STDIN>);

@project2 = split "/+",$Baseline_2;
$proj_name2 = "$project2[-1]";

############# copying baseline2 data to working copy ####################

`cp -r $Baseline_2/* $wc_path`;

die "$! $proj_name2 copying to working copy not successful " if $?;

print "\nSuccessfully copied the $count baseline data into working copy \n";

############# adding copied data in the working copy  ###################

`svn add --force --username $usr --password $pswd -q $wc_path/*`;

die "$! $proj_name2 sources adding to repository not successful " if $?;

############# committing baseline_2 added data into repository ##########

`svn commit --username $usr --password $pswd $wc_path -m "added baseline$count data are committed" > "$proj_name2.txt"`;

die "$! $proj_name2 commit not successful " if $?;

#################### creating baseline_2 tag ############################

`svn cp --username $usr --password $pswd $repo_path "$tag_path/$proj_name2" -m "creation of baseline$count tag"`; 

die "$! creation of $proj_name2 tag not successful " if $?;

print "\n successfully created baseline_$count tag \n";


}
}