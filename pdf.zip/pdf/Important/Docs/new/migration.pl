#!/usr/bin/env perl

##############################################################################
##   File Name		:	migration.pl						##
##   Description	:	Importing, adding of baseline codes into svn		##
##				repository and creating tags of those baseline codes  ##
##   Author		    :	Thulasi Ram 							##
##   Date		    :	26/08/2012								##
##   Team		    :	CM Team								##
##   Usage		    :	Reset the baseline directory, repository path		##
##													##
##############################################################################

print "\nEnter the existed repository path [Trunk / Branch]:";
chomp (my $repo_path=<STDIN>);
print "\nEnter the Baseline path to import:";
chomp (my $Baseline_1=<STDIN>);
print "\nEnter the 2nd Baseline path:";
chomp (my $Baseline_2=<STDIN>);
print "\nEnter the 3rd Baseline path:";
chomp (my $Baseline_3=<STDIN>);
print "\nEnter the tag path:";
chomp (my $tag_path=<STDIN>);
print "\nEnter the required working path:";
chomp (my $wc_path=<STDIN>);

############# Importing Baseline_1 initially into repository ############

`svn import $Baseline_1 $repo_path -m "Initial importing"`;

####################### checkouting working copy ########################

`svn checkout $repo_path $wc_path`;

#################### creating baseline_1 tag ############################

`svn cp $repo_path $tag_path/tag_Baseline_1 -m "creation of baseline_1 tag"`;

################## deleting working copy data ###########################

`svn del -q $wc_path\\*.*`;

#################### deleted data are committed #########################

`svn commit -q $wc_path -m "deletion of files are committed"`;

############# copying baseline2 data to working copy ####################

`xcopy /Y /E $Baseline_2\\*.* $wc_path`;

############# adding copied data in the working copy  ###################

`svn add -q $wc_path\\*.*`;

############# committing baseline_2 added data into repository ##########

`svn commit -q $wc_path -m "added baseline2 data are committed"` ;

#################### creating baseline_2 tag ############################

`svn cp $repo_path $tag_path/tag_Baseline_2 -m "creation of baseline_2 tag"`; 

#################### deleting working copy data #########################

`svn del -q $wc_path\\*.*`;

###################### deleted data committed ###########################

`svn commit -q $wc_path -m "deletion of files are committed"`;

#################### copying baseline3 data to working copy #############

`xcopy /Y /E $Baseline_3\\*.* $wc_path`;

################### adding copied data in the working copy  #############

`svn add -q $wc_path\\*.*`;

############# committing baseline_3 added data into repository ##########

`svn commit -q $wc_path -m "added baseline3 data are committed"` ;

############# creating baseline_3 tag   #################################

`svn cp $repo_path $tag_path/tag_Baseline_3 -m "creation of baseline_3 tag"`;