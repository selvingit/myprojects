#!/usr/bin/env perl

use File::Copy;
use Getopt::Long;
use File::Basename;

print "\nEnter the Source Path:";
my $sou=<STDIN>;
chomp $sou;

print "\nEnter last build revision no.:";
my $old=<STDIN>;
chomp $old;

print "\nEnter latest build revision no.:";
my $new=<STDIN>;
chomp $new;

print "\nEnter the tag with new tagname:";
my $dest=<STDIN>;
chomp $dest;

#`svn cp $sou\@$new $dest -m \"creating a tag\"`;
#print "\ntag created";

`svn diff --summarize -r $old:$new $sou > difflist.txt`;

open (out, ">output.txt");
open (list, "difflist.txt");
while ($line=<list>)
	{
		@arr=split /\s+/, $line;
		print out "$arr[1]  \n";		
	}
close list;
close out;
open (hello, "output.txt");
foreach (<hello>)
	{
		`svn cp $_ $dest -m "log"`; 
	}
#open (fol, ">folder.txt");
#while ($abc=<out>)
#	{
#		@ar=split /:/, $abc;
#		#print "$ar[2]";
#		$folder=dirname($ar[2]);
#		print fol "$folder\n";
#		
#	}

